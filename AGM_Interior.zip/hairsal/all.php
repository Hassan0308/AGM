<?php
include 'db.php';


 
	 
  
				?>
	
	
				



<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>All</title>
	    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>
	    



	
	
	
<div class="site-section">
      <div class="container">
		 
        
        <div class="row">
			 <?php
					$select= "select*from products ";
$query=mysqli_query($con,$select);
$rows= mysqli_num_rows($query);
	while($fetch=mysqli_fetch_array($query)){
				$image = $fetch['picture'];
$image_src = "Admin/img/".$image;
				?>
          <div class="col-md-6 col-lg-4 col-12 text-center mb-5 mb-lg-5">
          <div class="card" style=" height: 20rem;">
  <img src='<?php echo $image_src; ?>' height="250" width="100" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><?php echo $fetch['name'] ?></h5>

    
  </div>
</div>
			</div><?php }?></div>

      </div>
    </div>
</body>
</html>