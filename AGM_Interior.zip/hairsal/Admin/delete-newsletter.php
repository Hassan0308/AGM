<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
		<?php
	include '../db.php';

	$id=$_GET['id'];
	$delete="DELETE FROM subscriber WHERE id=$id";
	$result=mysqli_query($con , $delete);
	
	header('location:news-letter.php');

	
	
	?>
</head>

<body>
</body>
</html>