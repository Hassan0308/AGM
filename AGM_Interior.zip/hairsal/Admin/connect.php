<?php
$host = "localhost";
$username = "alimalik_alimalik";
$password = "alimalik@@web@1240";
$dbname = "alimalik_al_faiz_herbal";
$con = mysqli_connect($host,$username,$password,$dbname);
?>