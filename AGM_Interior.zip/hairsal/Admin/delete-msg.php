<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
		<?php
	include '../db.php';

	$id=$_GET['id'];
	$delete="DELETE FROM message WHERE id=$id";
	$result=mysqli_query($con , $delete);
	
	header('location:messages.php');

	
	
	?>
</head>

<body>
</body>
</html>