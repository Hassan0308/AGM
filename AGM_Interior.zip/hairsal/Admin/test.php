<?php
if (isset($_POST['submit'])) {
	if ($_POST['test'] == 'value1'){echo "string";}else{
		header('location: test.php');
	}

}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form accept="" method="post">
<input type="checkbox" name="test" value="value1">
<button type="submit" name="submit">send</button>
</form>
</body>
</html>