<!DOCTYPE html>
<html lang="en">
  <head>
    <title>AGM &mdash; Product</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
	  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
		<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
    
  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    



    <header class="site-navbar py-1" role="banner">

      <div class="container-fluid">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2" data-aos="fade-down">
            <h1 class="mb-0"><a href="index.html" class="text-black h2 mb-0"><img src="imgAGM/logo.png" alt=""></a></h1>
          </div>
          <div class="col-10 col-md-8 d-none d-xl-block" data-aos="fade-down">
            <nav class="site-navigation position-relative text-right text-lg-center" role="navigation">

              <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                <li class="">
                  <a href="index.php">Home</a></li>
				  <li><a href="about.php">About</a></li>
                <li class="active"><a href="services.php">Products</a></li>
                <li><a href="contact.php">Contact</a></li>
              </ul>
            </nav>
          </div>

          <div class="col-6 col-xl-2 text-right" data-aos="fade-down">
            <div class="d-none d-xl-inline-block">
              <ul class="site-menu js-clone-nav ml-auto list-unstyled d-flex text-right mb-0" data-class="social">
                <li>
                  <a href="#" class="pl-0 pr-3 text-black"><span class="icon-facebook"></span></a>
                </li>
                <li>
                  <a href="#" class="pl-3 pr-3 text-black"><span class="icon-twitter"></span></a>
                </li>
                <li>
                  <a href="#" class="pl-3 pr-3 text-black"><span class="icon-instagram"></span></a>
                </li>
                <li>
                  <a href="#" class="pl-3 pr-3 text-black"><span class="icon-youtube-play"></span></a>
                </li>
              </ul>
            </div>

            <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>

  

   

    <div class="slide-one-item home-slider owl-carousel">
  
      <div class="site-blocks-cover" style="background-image:url('imgAGM/bc.jpg');" data-aos="fade" data-stellar-background-ratio="0.5">
          <div class="row align-items-center justify-content-center text-center">

            <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
              <h2 class=" font-weight-light mb-2 display-1 h">Our Products!</h2>

              
            </div>
          </div>
        </div>
      </div>  

    </div>
	  <script>
	
	
	
	$(document).ready(function(){
   
   $('#all-content').load("all.php");
		
	$('#red-content').load("red.php");
		$('#green-content').load("green.php");
		$('#blue-content').load("blue.php");
		$('#red-content').hide();
		$('#green-content').hide();
		$('#blue-content').hide();
		
		
 $('#all').on('click', function(){
      // alert('click event');
			 $('#all-content').show();
	 $('#red-content').hide();
		$('#green-content').hide();
		$('#blue-content').hide();
	 
		
    });
		
		
		 $('#red').on('click', function(){
      // alert('click event');
			
	  $('#red-content').show();
			$('#green-content').hide();
		$('#blue-content').hide();
			 $('#all-content').hide();
    });
		 $('#green').on('click', function(){
      // alert('click event');
			
	  $('#green-content').show();
			$('#red-content').hide();
		$('#blue-content').hide();
			 $('#all-content').hide();
    });
			 $('#blue').on('click', function(){
      // alert('click event');
			
	  $('#blue-content').show();
			$('#red-content').hide();
		$('#green-content').hide();
			 $('#all-content').hide();
    });

});
</script>
	
	  
	  
<!--//Tabs-->
	
<div class="container mt-5 text-center">
<div class="row text-center" >
	<div class="col-lg-12 col-md-12 col-12 ">
		
<nav class="navbar navbar-expand-sm bg-light justify-content-center ">
	<div class="row">      
  <ul class="navbar-nav list-inline ">
 
    <li class="nav-item mr-5 mt-2 ">
		
   <button  id="all"  class="btn btn-dark">ALL</button>
    </li>
	  
    <li class="nav-item mr-5 mt-2">
      <button id="red" class="btn btn-dark">NEW</button>
    </li>
    <li class="nav-item mt-2">
      <button id="green" class="btn btn-dark">Featured</button>
    </li>
  </ul>
	
	</div>
</nav>

	</div>
	</div>
</div>
	  
<!--	  tabs-->
<!--	  area of content-->
	  <div id="all-content" style="width: 100%; height: auto;"></div>
	  <div id="red-content" style="width: 100%; height: auto;"></div>
	  <div id="green-content" style="width: 100%; height: auto;"></div>
	  <div id="blue-content" style="width: 100%; height: auto;"></div>



    

    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="">
              <h3 class="footer-heading mb-4">AGM Interior LLP</h3>
              <p>AGM has a dedicated team of well skilled, trained and
motivated professionals. If you want to build your dream home
or office with inspiration, state of the art designs and pristine
finishing then you have knocked at the right door. We are a
team that does not believe in compromising on quality.</p>
            </div>

            
            
          </div>
          <div class="col-lg-4  mb-lg-0">
            <div class="row mb-5">
              <div class="col-md-12">
                <h3 class="footer-heading mb-4">Quick Menu</h3>
              </div>
              <div class="col-md-6 col-lg-6">
                <ul class="list-unstyled">
                  <li><a href="index.php">Home</a></li>
                  <li><a href="contact.php">Contact us</a></li>
                  <li><a href="services.php">Services</a></li>
                  <li><a href="about.php">About</a></li>
                </ul>
              </div>
            
            </div>

            

          </div>

              <div class="col-lg-4  mb-lg-0">
			  	  <?php
		include 'db.php';
		if(isset($_POST["news"])){
		$newsemail=$_POST["emai"];
		$insert="INSERT INTO subscriber(email) VALUES ('$newsemail')";
		 $ro=$con->query($insert);
	if($ro){?>
	<script>alert('Thanks for Sending NewsLetter');
window.location.href="index.php"</script>
<?php
}else{?>
<script>alert(' NewsLetter not sendind Try Again!');</script>
<?php
}}?>
          <div class="mb-5">
              <h3 class="footer-heading mb-2">NewsLetter</h3>
              <p>Subscribe us for best services</p>

              <form action="#" method="post">
                <div class="input-group mb-3">
                  <input type="text" name="emai" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                  <div class="input-group-append">
                  <input type="submit" value="Send" class="btn btn-primary py-2 px-4 text-white" name="news">
                </div>
                  </div>
                </div>
              </form>

            </div>
          
        </div>
        <div class="row   text-center">
          <div class="col-md-12">
            <div class="mb-5">
              <a href="#" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
            </div>

            <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart-o" aria-hidden="true"></i> by HK
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
          
        </div>
      </div>
    </footer>



	  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>