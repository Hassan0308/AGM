<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "agm";
$con = mysqli_connect($host,$username,$password,$dbname);


?>