<!DOCTYPE html>
<html lang="en">
  <head>
    <title>AGM &mdash; About</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">


    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    



    <header class="site-navbar py-1" role="banner">

      <div class="container-fluid">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2" data-aos="fade-down">
           <h1 class="mb-0"><a href="index.html" class="text-black h2 mb-0"><img src="imgAGM/logo.png" alt=""></a></h1>
          </div>
          <div class="col-10 col-md-8 d-none d-xl-block" data-aos="fade-down">
            <nav class="site-navigation position-relative text-right text-lg-center" role="navigation">
 <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                <li class="">
                  <a href="index.php">Home</a></li>
				  <li class="active"><a href="about.php">About</a></li>
                <li class=""><a href="services.php">Products</a></li>
                <li class=""><a href="contact.php">Contact</a></li>
              </ul>
            </nav>
          </div>

          <div class="col-6 col-xl-2 text-right" data-aos="fade-down">
            <div class="d-none d-xl-inline-block">
              <ul class="site-menu js-clone-nav ml-auto list-unstyled d-flex text-right mb-0" data-class="social">
                <li>
                  <a href="#" class="pl-0 pr-3 text-black"><span class="icon-facebook"></span></a>
                </li>
                <li>
                  <a href="#" class="pl-3 pr-3 text-black"><span class="icon-twitter"></span></a>
                </li>
                <li>
                  <a href="#" class="pl-3 pr-3 text-black"><span class="icon-instagram"></span></a>
                </li>
                <li>
                  <a href="#" class="pl-3 pr-3 text-black"><span class="icon-youtube-play"></span></a>
                </li>
              </ul>
            </div>

            <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>

  

   

    <div class="slide-one-item home-slider owl-carousel">
   
     
      <div class="site-blocks-cover" style="background-image:url('imgAGM/bc.jpg');" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">

            <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
              <h2 class=" font-weight-light mb-2 display-1 h">About Us</h2>

              
            </div>
          </div>
        </div>
      </div>  

    </div>


<section>  
    <div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7">
            <h2 class="site-section-heading font-weight-light  text-center h">Managing Staff</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4 text-center mb-5" data-aos="fade-up">
            <img src="images/person_1.jpg" alt="Image" class="img-fluid w-50 rounded-circle mb-4">
            <h2 class="text-black font-weight-light mb-4">Mr. Asif Gulzar Malik</h2>
            <p class="mb-4">CEO of AGM Interior LLP </p>
            <p>
              <a href="#" class="pl-0 pr-3"><span class="icon-twitter"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-facebook"></span></a>
            </p>
          </div>
          <div class="col-md-6 col-lg-4 text-center mb-5" data-aos="fade-up">
            <img src="images/person_2.jpg" alt="Image" class="img-fluid w-50 rounded-circle mb-4">
            <h2 class="text-black font-weight-light mb-4">Mr. Salem Khan</h2>
            <p class="mb-4">Managing Director</p>
            <p>
              <a href="#" class="pl-0 pr-3"><span class="icon-twitter"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-facebook"></span></a>
            </p>
          </div>
          <div class="col-md-6 col-lg-4 text-center mb-5" data-aos="fade-up">
            <img src="images/person_4.jpg" alt="Image" class="img-fluid w-50 rounded-circle mb-4">
            <h2 class="text-black font-weight-light mb-4">Mr. Zahid Mahmood</h2>
            <p class="mb-4">Director Finance</p>
            <p>
              <a href="#" class="pl-0 pr-3"><span class="icon-twitter"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-facebook"></span></a>
            </p>
          </div>
        </div>
      </div>
    </div>
</section><section>   
    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5">
            <img src="imgAGM/440-4400642_our-goals-start-coding-hd-png-download.png" alt="Image" class="img-md-fluid img">
          </div>
          <div class="col-lg-6 bg-white p-md-5 align-self-center">
            <h2 class="display-1 text-black line-height-1 site-section-heading mb-4 pb-3">Our Goal</h2>
            <p class="text-black lead"><em>&ldquo;Our long experience helped us to develop a strategy, where we can deliver a
high class product at economic price. Our goal is not on a single sale but on
recurring orders from the very same customer. This simple but extremely
fruitful policy earned us great reputation in the town. By the grace of
Almighty, AGM is more focussed & fervent to ease up the lives of our
community. We, as a company has invested a lot to win the trust of the
people and we will continue our vigorous efforts to make a long-term growth
sustainable. We believe that there is no finish line in learning & improving
ourselves. We take every project as a challenge and when one challenge is
completed, another rises on the horizon, and AGM’s team is right there to
take up the new challenge.&rdquo;</em></p>
           
          </div>
        </div>
      </div>
    </div></section>
	  <section class=""   > 
	  <div class="site-section  ">
      <div class="container">
        <div class="row">
          
          <div class="col-lg-6 bg-white p-md-5 align-self-center ">
            <h2 class="display-1 text-black line-height-1 site-section-heading  ">Our Expertise
</h2>
            <p class="text-black lead"><em>&ldquo;• We concept, design and implement the latest ideas in Kitchens,
wardrobes and furniture. Our craftsmen are very skilled and zealous
in any product they manufacture. We use latest tools and machines in
our production areas and invest regularly to keep our tools up to date.
• We supply ICI Dulux & Berger Paints at very competitive rates to civil,
housing society’s or armed forces projects.
• We supply and install Canon & Haier appliances at very competitive
prices to any project.
• We supply Clipsal by Schneider’s products, FAST cables, Globright &
Coarts LEDs, PVC Panels, Wooden Floors, Wallpapers, Solar Panels &
Bravo Outdoor furniture.</em></p>
            
          </div>
			<div class="col-lg-6 ">
            <img src="imgAGM/853-8537442_our-expertise-includes-html-css-flash-flex-designing.png" alt="Image" class="img-md-fluid img">
          </div>
        </div>
      </div>
    </div>

  </section>
  

<footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="">
              <h3 class="footer-heading mb-4">AGM Interior LLP</h3>
              <p>AGM has a dedicated team of well skilled, trained and
motivated professionals. If you want to build your dream home
or office with inspiration, state of the art designs and pristine
finishing then you have knocked at the right door. We are a
team that does not believe in compromising on quality.</p>
            </div>

            
            
          </div>
          <div class="col-lg-4  mb-lg-0">
            <div class="row mb-5">
              <div class="col-md-12">
                <h3 class="footer-heading mb-4">Quick Menu</h3>
              </div>
              <div class="col-md-6 col-lg-6">
                <ul class="list-unstyled">
                  <li><a href="index.php">Home</a></li>
                  <li><a href="contact.php">Contact us</a></li>
                  <li><a href="services.php">Services</a></li>
                  <li><a href="about.php">About</a></li>
                </ul>
              </div>
            
            </div>

            

          </div>

           <div class="col-lg-4  mb-lg-0">
			  	  <?php
		include 'db.php';
		if(isset($_POST["news"])){
		$newsemail=$_POST["emai"];
		$insert="INSERT INTO subscriber(email) VALUES ('$newsemail')";
		 $ro=$con->query($insert);
	if($ro){?>
	<script>alert('Thanks for Sending NewsLetter');
window.location.href="about.php"</script>
<?php
}else{?>
<script>alert(' NewsLetter not sendind Try Again!');</script>
<?php
}}?>
          <div class="mb-5">
              <h3 class="footer-heading mb-2">NewsLetter</h3>
              <p>Subscribe us for best services</p>

              <form action="#" method="post">
                <div class="input-group mb-3">
                  <input type="text" name="emai" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                  <div class="input-group-append">
                  <input type="submit" value="Send" class="btn btn-primary py-2 px-4 text-white" name="news">
                </div>
                  </div>
                </div>
              </form>

            </div>
          
        </div>
        <div class="row   text-center">
          <div class="col-md-12">
            <div class="mb-5">
              <a href="#" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
              <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
            </div>

            <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart-o" aria-hidden="true"></i> by HK
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>